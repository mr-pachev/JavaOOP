import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

public class InstockTest {
    private Instock instock;

    @Before
    public void setupInstock() {
        this.instock = new Instock();
    }

    @Test
    public void testAddAndContains() {
        Product product = new Product("Cola", 2.40, 10);
        Assert.assertFalse(this.instock.contains(product));

        this.instock.add(product);
        Assert.assertTrue(this.instock.contains(product));
    }

    @Test
    public void testCount() {
        Assert.assertEquals(0, this.instock.getCount());

        fillStock();

        Assert.assertEquals(3, this.instock.getCount());
    }

    @Test
    public void testCorrectFindByIndex() {
        fillStock();
        Product expectedProduct = this.instock.find(2);

        Assert.assertEquals(expectedProduct.getLabel(), "Sprite");
        Assert.assertEquals(expectedProduct.getPrice(), 3.20, 0.00);
        Assert.assertEquals(expectedProduct.getQuantity(), 2);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testFindByNegativeIndex() {
        fillStock();
        Product expectedProduct = this.instock.find(-1);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testFindByOutRange() {
        fillStock();
        Product expectedProduct = this.instock.find(8);
    }

    @Test
    public void testChangeQuantityWithExistProduct() {
        fillStock();
        Product currentProduct = this.instock.find(1);

        this.instock.changeQuantity(currentProduct.getLabel(), 8);

        Assert.assertEquals(currentProduct.getQuantity(), 8);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testChangeQuantityWhitNotExistProduct() {
        fillStock();
        Product product = new Product("bread", 1.90, 5);

        this.instock.changeQuantity(product.getLabel(), 8);

        Assert.assertEquals(product.getQuantity(), 8);
    }

    @Test
    public void testFindByLabelWithCorrectLabel() {
        fillStock();
        Product findProduct = this.instock.findByLabel("Fanta");
        Product expectedProduct = new Product("Fanta", 1.20, 4);

        Assert.assertEquals(findProduct.getLabel(), expectedProduct.getLabel());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindByLabelByNonExistentLabel() {
        fillStock();
        Product findProduct = this.instock.findByLabel("bread");
    }

    @Test
    public void testFindFirstByAlphabeticalOrderCorrectN() {
        fillStock();
        Iterable<Product> iterable = this.instock.findFirstByAlphabeticalOrder(2);
        int countProducts = 0;

        for (Product product : iterable) {
            countProducts++;
        }

        assertEquals(countProducts, 2);
    }

    @Test
    public void testFindFirstByAlphabeticalOrderInCorrectN() {
        fillStock();
        Iterable<Product> iterable = this.instock.findFirstByAlphabeticalOrder(5);
        List<Product> instockLabelList = iterableToList(iterable);

        assertTrue(instockLabelList.isEmpty());
    }


    @Test
    public void testFindFirstByAlphabeticalOrderCorrectSorted() {
        List<Product> productsLabelList = new ArrayList<>();

        Product productOne = new Product("Cola", 1.20, 6);
        Product productTwo = new Product("Fanta", 1.20, 4);
        Product productThree = new Product("Sprite", 1.20, 2);

        this.instock.add(productOne);
        productsLabelList.add(productOne);
        this.instock.add(productTwo);
        productsLabelList.add(productTwo);
        this.instock.add(productThree);
        productsLabelList.add(productThree);

        productsLabelList = productsLabelList.stream()
                .sorted(Comparator.comparing(Product::getLabel))
                .collect(Collectors.toList());

        Iterable<Product> iterable = this.instock.findFirstByAlphabeticalOrder(3);
        List<Product> expectedSortedList = iterableToList(iterable);

        assertEquals(productsLabelList, expectedSortedList);
    }

    @Test
    public void testFindAllInPriceRangeCorrectRange() {
        fillStock();
        Iterable<Product> iterable = this.instock.findAllInRange(1.10, 3.20);
        List<Product> expectedProducts = new ArrayList<>();

        for (Product product : iterable) {
            expectedProducts.add(product);
        }
        assertEquals(expectedProducts.size(), 3);
    }

    @Test
    public void testFindAllInPriceRangeCorrectSorted() {
        fillStock();
        Iterable<Product> iterable = this.instock.findAllInRange(1.10, 3.20);

        List<Product> findProducts = new ArrayList<>();
        for (Product product : iterable) {
            findProducts.add(product);
        }

        assertEquals(findProducts.get(0).getPrice(), 3.20, 0.00);
        assertEquals(findProducts.get(1).getPrice(), 2.20, 0.00);
        assertEquals(findProducts.get(2).getPrice(), 1.20, 0.00);
    }

    @Test
    public void testFindAllInPriceRangeInCorrectRange(){
        fillStock();
        Iterable<Product> iterable = this.instock.findAllInRange(20,30);

        assertFalse(iterable.iterator().hasNext());
    }

    @Test
    public void testFindAllByPriceWithCorrectPrice(){
        fillStock();
        Iterable<Product> iterable = this.instock.findAllByPrice(1.20);
        List<Product> findProducts = new ArrayList<>();

        for (Product product : iterable){
            findProducts.add(product);
        }

        Assert.assertEquals(findProducts.get(0).getPrice(),1.20, 0.00);
    }

    @Test
    public void testFindAllByPriceWithInCorrectPrice(){
        fillStock();
        Iterable<Product> iterable = this.instock.findAllByPrice(9.20);
        Assert.assertFalse(iterable.iterator().hasNext());
    }

    @Test
    public void testFindAllByQuantityWithCorrectQuantity(){
        fillStock();
        Iterable<Product> iterable = this.instock.findAllByQuantity(4);
        List<Product> findProducts = new ArrayList<>();

        for (Product product : iterable){
            findProducts.add(product);
        }

        Assert.assertEquals(4, findProducts.get(0).getQuantity());
    }

    @Test
    public void testFindAllByQuantityWithInCorrectQuantity(){
        fillStock();
        Iterable<Product> iterable = this.instock.findAllByPrice(20);
        Assert.assertFalse(iterable.iterator().hasNext());
    }

    @Test
    public void testGetIterable(){
        List<Product> current = Arrays.asList(new Product("Cola", 1.20, 6),
                                              new Product("Fanta", 2.20, 4),
                                              new Product("Sprite", 3.20, 2));

        fillStock();
        Iterator<Product> iterator = this.instock.iterator();
        List<Product> iteratorToList = new ArrayList<>();

        while (iterator.hasNext()){
            Product product = iterator.next();
            iteratorToList.add(product);
        }

        Assert.assertEquals(current.get(0).getLabel(), iteratorToList.get(0).getLabel());
        Assert.assertEquals(current.get(1).getLabel(), iteratorToList.get(1).getLabel());
        Assert.assertEquals(current.get(2).getLabel(), iteratorToList.get(2).getLabel());

    }

    @Test
    public void testFindFirstMostExpensiveProductsWithCorrectN(){
        fillStock();
        Iterable<Product> iterable = this.instock.findFirstMostExpensiveProducts(1);
        List<Product> findProducts = new ArrayList<>();

        for (Product product : iterable){
            findProducts.add(product);
        }

        Assert.assertEquals(3.20, findProducts.get(0).getPrice(), 0.00);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testFindFirstMostExpensiveProductsWithInCorrectN(){
        fillStock();
        Iterable<Product> iterable = this.instock.findFirstMostExpensiveProducts(4);
    }



    private void fillStock() {
        Product productOne = new Product("Cola", 1.20, 6);
        Product productTwo = new Product("Fanta", 2.20, 4);
        Product productThree = new Product("Sprite", 3.20, 2);

        this.instock.add(productOne);
        this.instock.add(productTwo);
        this.instock.add(productThree);
    }

    private static List<Product> iterableToList(Iterable<Product> iterable) {
        List<Product> instockLabelList = new ArrayList<>();

        for (Product product : iterable) {
            instockLabelList.add(product);
        }
        return instockLabelList;
    }
}