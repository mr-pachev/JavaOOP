import jdk.jshell.spi.ExecutionControl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Instock implements ProductStock {
    private List<Product> productsList;

    public Instock() {
        this.productsList = new ArrayList<>();
    }

    public List<Product> getProductsList() {
        return productsList;
    }

    public void setProductsList(List<Product> productsList) {
        this.productsList = productsList;
    }

    @Override
    public int getCount() {
        return this.productsList.size();
    }

    @Override
    public boolean contains(Product product) {
        return this.productsList.contains(product);
    }

    @Override
    public void add(Product product) {
        this.productsList.add(product);
    }

    @Override
    public void changeQuantity(String product, int quantity) {
        Product currentProduct = this.productsList.stream()
                .filter(f -> f.getLabel().equals(product))
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);

        currentProduct.setQuantity(quantity);
    }

    @Override
    public Product find(int index) {
        return this.productsList.get(index);
    }

    @Override
    public Product findByLabel(String label) {
        return this.productsList
                .stream()
                .filter(p -> p.getLabel().equals(label))
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);
    }

    @Override
    public Iterable<Product> findFirstByAlphabeticalOrder(int count) {
        if (count <= 0 || count > this.productsList.size()) {
            return new ArrayList<>();
        }

        return this.productsList
                .stream()
                .sorted(Comparator.comparing(Product::getLabel))
                .limit(count)
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findAllInRange(double lo, double hi) {
        return this.productsList
                .stream()
                .filter(p -> p.getPrice() > lo && p.getPrice() <= hi)
                .sorted(Comparator.comparing(Product::getPrice).reversed())
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findAllByPrice(double price) {
        return this.productsList
                .stream()
                .filter(p -> p.getPrice() == price)
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Product> findFirstMostExpensiveProducts(int count) {
        this.productsList = this.productsList
                .stream()
                .sorted(Comparator.comparing(Product::getPrice).reversed())
                .limit(count)
                .collect(Collectors.toList());

        if (productsList.size() < count){
            throw new IllegalArgumentException();
        }
        return this.productsList;
    }

    @Override
    public Iterable<Product> findAllByQuantity(int quantity) {
        return this.productsList
                .stream()
                .filter(p -> p.getQuantity() == quantity)
                .collect(Collectors.toList());
    }

    @Override
    public Iterator<Product> iterator() {
        return this.productsList.iterator();
    }
}
