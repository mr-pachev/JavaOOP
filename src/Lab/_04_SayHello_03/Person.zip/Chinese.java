

public class Chinese implements Person{
    public Chinese(String name) {
        this.name = name;
    }

    private String name;
    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }
}
