

public class Topping {
    private String toppingType;
    private double weight;

//    private String toppingType;
//    private double weight;
//    private double calories;

    public Topping(String toppingType, double weight) {
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

//    public Topping(String toppingType, double wight) {
//        setToppingType(toppingType);
//        setWeight(wight);
//    }

    public double calculateCalories (){
        return (this.weight * 2) * getModifier();
    }

//    public double calculateCalories() {
//        return (2 * this.weight) * this.calories;
//    }
    private double getModifier(){
        switch (this.toppingType){
            case "Meat":
                return 1.2;
            case "Veggies":
                return 0.8;
            case "Cheese":
                return 1.1;
            case "Sauce":
               return  0.9;
            default:
                return 0;
        }
    }

//    private void setToppingType(String toppingType) {
//        if (!toppingType.equals("Meat") && !toppingType.equals("Veggies") && !toppingType.equals("Cheese") && !toppingType.equals("Sauce")) {
//            throw new IllegalArgumentException(String.format("Cannot place %s on top of your pizza.", toppingType));
//        }
//
//        this.toppingType = toppingType;
//        switch (this.toppingType) {
//            case "Meat":
//                setCalories(1.2);
//                break;
//            case "Veggies":
//                setCalories(0.8);
//                break;
//            case "Cheese":
//                setCalories(1.1);
//                break;
//            case "Sauce":
//                setCalories(0.9);
//                break;
//        }
//    }
    private void setToppingType(String toppingType) {
        switch (toppingType){
            case "Meat":
            case "Veggies":
            case "Cheese":
            case "Sauce":
                this.toppingType = toppingType;
                break;
            default:
                String message = String.format("Cannot place %s on top of your pizza.", toppingType);
                throw new IllegalArgumentException(message);
        }

    }

    private void setWeight(double weight) {
        if ( weight < 1 || weight > 50){
            String message = String.format("%s weight should be in the range [1..50].", this.toppingType);
            throw new IllegalArgumentException(message);
        }
        this.weight = weight;
    }
//    private void setWeight(double weight) {
//        if (weight > 50 || weight < 1) {
//            throw new IllegalArgumentException(String.format("%s weight should be in the range [1..50].", this.toppingType));
//        }
//        this.weight = weight;
//    }

}
