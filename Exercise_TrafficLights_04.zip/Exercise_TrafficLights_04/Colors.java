package Exercise_TrafficLights_04;

public enum Colors {
    RED,
    GREEN,
    YELLOW;



}
