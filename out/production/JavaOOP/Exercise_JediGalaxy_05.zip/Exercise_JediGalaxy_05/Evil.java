package Exercise_JediGalaxy_05;

public class Evil {
    private int currentRowEvil;
    private  int currentColEvil;

    public Evil(int currentRowEvil, int currentColEvil) {
        this.currentRowEvil = currentRowEvil;
        this.currentColEvil = currentColEvil;
    }

    public void isEvilMovement(int[][] matrix, int currentRowEvil, int currentColEvil) {
        while (currentRowEvil >= 0 && currentColEvil >= 0) {
            if (isValidPosition(matrix, currentRowEvil, currentColEvil)) {
                matrix[currentRowEvil][currentColEvil] = 0;
            }
            currentRowEvil--;
            currentColEvil--;
        }
    }
    private boolean isValidPosition(int[][] matrix, int row, int col) {
        return row >= 0 && row < matrix.length && col >= 0 && col < matrix[row].length;
    }
}
