package Exercise_JediGalaxy_05;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] matrixSize = Arrays.stream(scanner.nextLine()
                        .split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();

        int rows = matrixSize[0];
        int cols = matrixSize[1];
        Matrix matrix = new Matrix(rows, cols);
        matrix.fillMatrix();

        int[][] galaxy = matrix.getMatrix();

        String command = scanner.nextLine();
        long sum = 0;


        while (!command.equals("Let the Force be with you")) {
            int[] jediStartPosition = Arrays.stream(command.split(" "))
                    .mapToInt(Integer::parseInt)
                    .toArray();

            int currentRowJedi = jediStartPosition[0];
            int currentColJedi = jediStartPosition[1];

            int[] evilStartPosition = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(Integer::parseInt)
                    .toArray();

            int currentRowEvil = evilStartPosition[0];
            int currentColEvil = evilStartPosition[1];

            Evil evil = new Evil(currentRowEvil, currentColEvil);
            evil.isEvilMovement(galaxy, currentRowEvil, currentColEvil);

            Jedi jedi = new Jedi(currentRowJedi, currentColJedi);
            sum = jedi.getSumJediMovement(galaxy, currentRowJedi, currentColJedi);

            command = scanner.nextLine();
        }
        System.out.println(sum);

    }

    //предвижване на джедая
    private long getSumJediMovement(int[][] matrix, long sum, int currentRowJedi, int currentColJedi) {
        while (currentRowJedi >= 0 && currentColJedi < matrix[1].length) {
            if (isValidPosition(matrix, currentRowJedi, currentColJedi)) {
                sum += matrix[currentRowJedi][currentColJedi];
            }
            currentColJedi++;
            currentRowJedi--;
        }
        return sum;
    }

    //предвижване на злото
    private static void isEvilMovement(int[][] matrix, int currentRowEvil, int currentColEvil) {
        while (currentRowEvil >= 0 && currentColEvil >= 0) {
            if (isValidPosition(matrix, currentRowEvil, currentColEvil)) {
                matrix[currentRowEvil][currentColEvil] = 0;
            }
            currentRowEvil--;
            currentColEvil--;
        }
    }

    //владиция на позицията
    public static boolean isValidPosition(int[][] matrix, int row, int col) {
        return row >= 0 && row < matrix.length && col >= 0 && col < matrix[row].length;
    }
}
