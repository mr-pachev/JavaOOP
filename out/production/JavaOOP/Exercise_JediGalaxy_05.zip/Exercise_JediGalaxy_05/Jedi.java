package Exercise_JediGalaxy_05;

public class Jedi {
    private int currentRowEvil;
    private int currentColEvil;

    public Jedi(int currentRowEvil, int currentColEvil) {
        this.currentRowEvil = currentRowEvil;
        this.currentColEvil = currentColEvil;
    }

    public long getSumJediMovement(int[][] matrix, int currentRowJedi, int currentColJedi) {
        long sum = 0;
        while (currentRowJedi >= 0 && currentColJedi < matrix[1].length) {
            if (isValidPosition(matrix, currentRowJedi, currentColJedi)) {
                sum += matrix[currentRowJedi][currentColJedi];
            }
            currentColJedi++;
            currentRowJedi--;
        }
        return sum;
    }

    private boolean isValidPosition(int[][] matrix, int row, int col) {
        return row >= 0 && row < matrix.length && col >= 0 && col < matrix[row].length;
    }
}
