package Exercise_JediGalaxy_05;

public class Matrix {
    private int[][] matrix;
    private int rows;
    private int cols;

    public Matrix(int rows, int cols) {
        this.matrix = new int[rows][cols];
        this.rows = rows;
        this.cols = cols;
    }

    public void fillMatrix(){
        int filedValue = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
               this.matrix[i][j] = filedValue++;
            }
        }
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public void setMatrix(int[][] matrix) {
        this.matrix = matrix;
    }
}
