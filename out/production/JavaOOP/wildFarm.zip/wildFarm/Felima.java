package wildFarm;

public abstract class Felima extends Mammal{

    public Felima(String animalName, String animType, Double animalWeight, String livingRegion) {
        super(animalName, animType, animalWeight, livingRegion);
    }
}
