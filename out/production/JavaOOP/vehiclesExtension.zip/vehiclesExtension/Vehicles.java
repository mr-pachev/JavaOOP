package vehiclesExtension;

public interface Vehicles {
    String driving(double distance);
    void refueling (double liters);
}
