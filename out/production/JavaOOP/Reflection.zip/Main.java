import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {

        Class<Reflection> reflectionClass = Reflection.class;

//        Task 1.
//
//        System.out.println(reflectionClass);
//        System.out.println(Reflection.class.getSuperclass());
//
//        Class<?>[] interfaces = reflectionClass.getInterfaces();
//
//        for (Class<?> anInterface : interfaces) {
//            System.out.println(anInterface);
//        }
//
//        Reflection reflection = (Reflection) Class.forName(Reflection.class.getName()).getConstructor().newInstance();
//        System.out.println(reflection);


        Method[] declaredMethods = reflectionClass.getDeclaredMethods();

        Arrays.stream(declaredMethods)
                .filter(Main::isGetter)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(m -> System.out.printf("%s will return class %s%n",
                        m.getName(),
                        m.getReturnType().getName()));

        Arrays.stream(declaredMethods)
                .filter(Main::isSetter)
                .sorted(Comparator.comparing(Method::getName))
                .forEach(m -> System.out.printf("%s and will set field of class %s%n",
                        m.getName(),
                        m.getParameterTypes()[0].getName()));


    }
    public static boolean isGetter (Method method){
        if (!method.getName().startsWith("get")){
            return false;
        }

        if (method.getReturnType().equals(void.class)){
            return false;
        }

        if (method.getParameterCount() > 0){
            return false;
        }
        return true;
    }

    public static boolean isSetter (Method method){

        if (!method.getName().startsWith("set")){
            return false;
        }

        if (!method.getReturnType().equals(void.class)){
            return false;
        }

        if (method.getParameterCount() != 1){
            return false;
        }
        return true;
    }
}
