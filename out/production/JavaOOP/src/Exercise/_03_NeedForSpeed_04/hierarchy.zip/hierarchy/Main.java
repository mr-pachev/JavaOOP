package hierarchy;

public class Main {
}
