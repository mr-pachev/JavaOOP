

public interface Browsable {
    String browse();
}
