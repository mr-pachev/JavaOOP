
import java.util.List;

public class Smartphone implements Callable, Browsable {

    private List<String> numbers;
    private List<String> urls;

    public Smartphone(List<String> numbers, List<String> urls) {
        this.numbers = numbers;
        this.urls = urls;
    }

    @Override
    public String browse() {
        StringBuilder builder = new StringBuilder();
        for (String url : urls) {
            boolean isDigit = false;

            for (int i = 0; i < url.length(); i++) {   //текущата страница

                if (Character.isDigit(url.charAt(i))){
                    isDigit = true;
                }
            }

            if (isDigit) {
                builder.append("Invalid URL!").append(System.lineSeparator());
            } else {
                builder.append(String.format("Browsing: %s", url)).append(System.lineSeparator());
            }
        }
        return builder.toString();
    }

    @Override
    public String call() {
        StringBuilder builder = new StringBuilder();
        for (String number : numbers) {
            boolean isDigit = true;

            for (int i = 0; i < number.length(); i++) {

                if (!Character.isDigit(number.charAt(i))){
                    isDigit = false;
                }
            }

            if (!isDigit) {
                builder.append("Invalid number!").append(System.lineSeparator()) ;
            } else {
                builder.append(String.format("Calling... %s", number)).append(System.lineSeparator());
            }
        }
        return builder.toString();
    }
}
