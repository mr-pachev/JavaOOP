package src.Exercise._04_MultipleImplementation_02;

public interface Person {
    String getName();
    int getAge();
}
