

public class Animal {
    public Animal() {
    }

    public void eat(){
        System.out.println("eating...");
    }
}
