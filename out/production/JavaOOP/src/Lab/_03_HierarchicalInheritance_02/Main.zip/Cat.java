

public class Cat extends Animal {
    public Cat() {
    }

    public void meow(){
        System.out.println("meow...");
    }
}
