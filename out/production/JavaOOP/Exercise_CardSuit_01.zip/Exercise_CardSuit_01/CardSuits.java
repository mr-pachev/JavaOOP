package Exercise_CardSuit_01;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
